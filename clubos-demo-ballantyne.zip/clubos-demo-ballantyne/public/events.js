// ════════════════════════════════════════════════════════════════
//  ClubOS Promote — DEMO event data for Ballantyne Country Club
//  This is the only file to edit when the event list changes.
//
//  ⚠ PLACEHOLDER EVENTS — replace with the real Ballantyne events
//    before the Oct 20 meeting. Keep the same fields.
//
//  date:        'YYYY-MM-DD'      start/end: '6:00 PM' style
//  cap:         max attendees (0 = no cap)
//  going:       seeded RSVP count for the demo
//  early:       how many of those signed up in the first 48 hours
//  checkedIn:   seeded check-ins (only for events already held)
//  who:         a few first names + last initials shown as "who's in"
//               (demo names — never real member names)
// ════════════════════════════════════════════════════════════════

window.CLUBOS_VENUE = {
  name: 'Ballantyne Country Club',
  short: 'BCC',
  crest: 'B',
  openHour: 7,
  closeHour: 21,
  channel: 'clubos-demo-ballantyne-promote'
};

window.CLUBOS_EVENTS = [
  {
    id: 'mixer',
    title: 'Fall Doubles Mixer',
    category: 'Racquet',
    date: '2026-10-24', start: '4:00 PM', end: '7:00 PM',
    location: 'Tennis Courts 1–4',
    blurb: 'Round-robin doubles, rotating partners every 20 minutes. All levels. Drinks on the terrace after.',
    signup: 'BCC App or Pro Shop',
    cap: 32, going: 21, early: 9,
    who: ['Jordan K.', 'Mia R.', 'Chris T.', 'Dana L.', 'Sam W.']
  },
  {
    id: 'pickle-night',
    title: 'Pickleball Under the Lights',
    category: 'Racquet',
    date: '2026-10-22', start: '6:30 PM', end: '8:30 PM',
    location: 'Pickleball Courts',
    blurb: 'Open play with music and a pro on court for drills. Paddles available at the Pro Shop.',
    signup: 'BCC App or Pro Shop',
    cap: 24, going: 18, early: 7,
    who: ['Alex P.', 'Taylor B.', 'Riley M.', 'Casey D.']
  },
  {
    id: 'clinic',
    title: "Women's 3.5 Drill Clinic",
    category: 'Racquet',
    date: '2026-10-27', start: '9:00 AM', end: '10:30 AM',
    location: 'Court 5',
    blurb: 'Serve, return, and net-play drills with the tennis pro. Limited to eight players.',
    signup: 'BCC App or Pro Shop',
    cap: 8, going: 6, early: 5,
    who: ['Lauren S.', 'Kim H.', 'Jess A.']
  },
  {
    id: 'halloween',
    title: 'Family Halloween Night',
    category: 'Club Social',
    date: '2026-10-31', start: '5:30 PM', end: '8:00 PM',
    location: 'Clubhouse & Lawn',
    blurb: 'Costume parade, trunk-or-treat, and a kids buffet. Bring the whole family.',
    signup: 'BCC App or Front Desk',
    cap: 0, going: 64, early: 22,
    who: ['The Parkers', 'The Nguyens', 'The Bells', 'The Ortizes']
  },
  {
    id: 'wine',
    title: 'Fall Wine Dinner',
    category: 'Dining',
    date: '2026-11-06', start: '7:00 PM', end: '9:30 PM',
    location: 'Main Dining Room',
    blurb: 'Four courses paired with fall releases, hosted by the chef.',
    signup: 'BCC App or Front Desk',
    cap: 60, going: 38, early: 19,
    who: ['Mark & Ellen', 'Priya S.', 'Tom R.']
  }
];
